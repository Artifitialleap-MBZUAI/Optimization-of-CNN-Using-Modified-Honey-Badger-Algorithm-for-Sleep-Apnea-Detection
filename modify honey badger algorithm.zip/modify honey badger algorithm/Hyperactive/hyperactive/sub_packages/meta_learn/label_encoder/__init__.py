# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License


from .label_encoder_dict import label_encoder_dict

__all__ = ["label_encoder_dict"]

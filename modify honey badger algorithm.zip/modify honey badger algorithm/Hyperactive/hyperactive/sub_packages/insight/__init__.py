# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License


from .insight import Insight

__all__ = ["Insight"]

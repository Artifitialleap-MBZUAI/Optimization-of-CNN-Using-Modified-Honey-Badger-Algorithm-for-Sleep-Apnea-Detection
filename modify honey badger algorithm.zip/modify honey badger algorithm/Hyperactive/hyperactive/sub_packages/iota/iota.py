# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License


class Iota:
    def __init__(self):
        pass

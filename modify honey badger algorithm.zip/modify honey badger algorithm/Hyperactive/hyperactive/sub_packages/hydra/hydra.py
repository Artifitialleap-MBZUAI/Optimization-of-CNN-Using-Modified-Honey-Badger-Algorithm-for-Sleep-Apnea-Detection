# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License


class Hydra:
    def __init__(self):
        pass

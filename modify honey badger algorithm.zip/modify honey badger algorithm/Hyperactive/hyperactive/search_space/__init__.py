# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License


from .search_space import SearchSpace


__all__ = ["SearchSpace"]
